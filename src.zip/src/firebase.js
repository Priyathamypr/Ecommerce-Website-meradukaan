const firebaseConfig = {
    apiKey: "AIzaSyDJgFlr6QxLT1LzK_AEYUr7yNonI81uy0Q",
    authDomain: "mera-dukaan-b8a93.firebaseapp.com",
    databaseURL: "https://mera-dukaan-b8a93.firebaseio.com",
    projectId: "mera-dukaan-b8a93",
    storageBucket: "mera-dukaan-b8a93.appspot.com",
    messagingSenderId: "273391512483",
    appId: "1:273391512483:web:212c95b3c885d251570816",
    measurementId: "G-VVZPB2PFMG"
  };