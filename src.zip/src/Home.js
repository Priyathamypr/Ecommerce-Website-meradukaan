import React from 'react'
import './Home.css';
import Product from './Product'
function Home() {
    return (
        <div className="Home">
          <div className="home_container">
              
              <img className="home_image" src="https://wallpaperaccess.com/full/1429807.jpg" alt="title.logo"></img>
         
          </div> 
          <div className="home_row">
              <Product title="Samsung S20" price={1199} image="https://www.gizmozones.com/wp-content/uploads/2020/01/Samsung-S20.png" rating={4}/>
              <Product title="Iphone 12" price={1299} image="https://zdnet4.cbsistatic.com/hub/i/r/2020/10/21/25999ae5-5538-41da-b025-eb44ce8b8c81/resize/1200xauto/b82044831c8ab0ed40a66911565aeb10/iphone-12-pro-max-blue-hero.png" rating={5}/>
              </div> 
              <div className="home_row">
              <Product title="Dell Inspiron" price={949} image="https://www.kindpng.com/picc/m/609-6093321_dell-inspiron-15-3593-hd-png-download.png" rating={4}/>
              <Product title="MacBook Air" price={1299} image="https://i.pinimg.com/originals/54/36/47/54364703b2568f8b7db719456c47ead3.png" rating={4}/>
              <Product title="MacBook Pro" price={1299} image="https://www.freepnglogos.com/uploads/macbook-png/macbook-cleanmymac-the-best-mac-cleanup-app-for-macos-get-32.png" rating={5}/>
              </div> 
              <div className="home_row">      
              <Product title="Samsung Smart Tv 40-Inch" price={1299} image="https://images.samsung.com/is/image/samsung/au-suhd-k5500-ua40k5500awxxy-006-front-black?$L2-Thumbnail$" rating={5}/>
              </div> 
              <div className="home_row">
              <Product title="Samsung Note 20+" price={1199} image="https://images.samsung.com/is/image/samsung/eg/galaxy-note20/gallery/eg-galaxy-note20-ultra-n985-sm-n985fzngegy-frontmysticbronze-274061152" rating={4}/>
              <Product title="Apple Ipad Pro" price={1299} image="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/ipad-pro-11-select-wifi-spacegray-202003_FMT_WHH?wid=940&hei=1112&fmt=png-alpha&qlt=80&.v=1583546263566" rating={5}/>
              </div>
              <div className="home_row">      
              <Product title="HP Gaming Monitor 144Hz Display" price={1299} image="https://5.imimg.com/data5/TO/KD/GLADMIN-42540481/27mp59g-1ms-ips-gaming-monitor-500x500.png" rating={5}/>
              </div> 
              <div className="home_row">
              <Product title="Google HomePod" price={299} image="https://s1.poorvikamobile.com/image/data/description/AppleHomePod/Apple-Homepod.png" rating={4}/>
              <Product title="Amazon Alexa" price={269} image="https://assets.stickpng.com/images/5871217c38315b0eebc1da26.png" rating={5}/>
              </div>
              
        </div>
    );
}

export default Home
