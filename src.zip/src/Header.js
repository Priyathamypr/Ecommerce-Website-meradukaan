    import React from 'react';
    import './Header.css';
    import SearchIcon from "@material-ui/icons/Search";
    import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
    import { Link } from 'react-router-dom'; 
import { useStateValue } from './StateProvider';
import mainlogo from './mainlogo.png';
    
    function Header() {
        const [{basket},state]=useStateValue();
        return (
            <div className='header'>
                <Link to ='/'>
              <img className="header_logo"alt="meradukaan.logo" src={mainlogo}></img> 
              </Link> 
            <div className="header_search">
                <input className="header_searchInput" type="text"></input>
                <SearchIcon className="header_searchicon"></SearchIcon>
            </div>
            <div className="header_nav">
                <Link to="/login"><div className="header_option"><span className="optionslineone">Sign In</span></div></Link>
                <div className="header_option"><span className="optionslineone">My Orders</span></div>
            </div>
            <Link to ="/checkout">
            <div className="header_basket">
                <ShoppingCartIcon/>
                <span className="header_option header_basketcount">{basket?.length}</span>
            </div>
            </Link>
            
            </div>
            

            
        );
    }
    
    export default Header
    